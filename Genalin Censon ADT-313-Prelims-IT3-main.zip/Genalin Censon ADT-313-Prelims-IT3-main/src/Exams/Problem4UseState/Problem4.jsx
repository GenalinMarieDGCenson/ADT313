import React, { useState } from 'react';

export default function Problem4() {
  const [formValues, setFormValues] = useState({
    name: '',
    yearLevel: '',
    course: 'BSCS'
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(formValues); 
    alert(JSON.stringify(formValues, null, 2));
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ display: 'block' }}>
      Name: <input type='text' name='name' value={formValues.name} onChange={handleChange} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input type='radio' id='firstYear' name='yearlevel' value='Fist Year' />
          <label for='firstYear'>Fist Year</label>
        <br />
        <input type='radio' id='secondYear' name='yearLevel' value='Second Year' onChange={handleChange} />
          <label htmlFor='secondYear'>Second Year</label>
        <br />
        <input type='radio' id='thirdYear' name='yearLevel' value='Third Year' onChange={handleChange} />
          <label htmlFor='thirdYear'>Third Year</label>
        <br />
        <input type='radio' id='fourthYear' name='yearLevel' value='Fourth Year' onChange={handleChange} />
          <label htmlFor='fourthYear'>Fourth Year</label>
        <br />
        <input type='radio' id='fifthYear' name='yearLevel' value='Fifth Year' onChange={handleChange} />
          <label htmlFor='fifthYear'>Fifth Year</label>
        <br />
        <input type='radio' id='irregular' name='yearLevel' value='Irregular' onChange={handleChange} />
          <label htmlFor='irregular'>Irregular</label>
        <br />
      </div>

      <div style={{ display: 'block' }}>
        Course:
        <select name='course' value={formValues.course} onChange={handleChange}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>

      <button type='submit'>Submit</button>

      {/* Displaying the form data as an object */}
      <pre>{JSON.stringify(formValues, null, 2)}</pre>
    </form>
  );
}