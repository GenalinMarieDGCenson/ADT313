import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(true);
  const idleTimeoutRef = useRef(null);

  useEffect(() => {
    
    const loadingTimeout = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(loadingTimeout); 
  }, []);

  const resetIdleTimer = () => {
    setIsIdle(false);
    if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);

    
    idleTimeoutRef.current = setTimeout(() => {
      setIsIdle(true);
    }, 2000);
  };

  useEffect(() => {
    
    const handleUserActivity = () => resetIdleTimer();

    document.addEventListener('keydown', handleUserActivity);
    document.addEventListener('mousemove', handleUserActivity);

    return () => {
      
      document.removeEventListener('keydown', handleUserActivity);
      document.removeEventListener('mousemove', handleUserActivity);
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type='text' onKeyDown={resetIdleTimer} />
          <p>{isIdle ? 'User is idle...' : 'User is typing...'}</p>
        </div>
      )}
    </>
  );
}
