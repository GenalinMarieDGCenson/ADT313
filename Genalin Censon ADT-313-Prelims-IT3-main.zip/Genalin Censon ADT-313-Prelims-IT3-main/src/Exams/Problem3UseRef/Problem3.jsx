import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef([]);

  const handleClick = () => {
    // Find the first empty input field and focus on it
    const emptyInput = inputRefs.current.find(input => input && input.value === '');
    if (emptyInput) {
      emptyInput.focus();
    }
  };

  return (
    <>
      {[...Array(10)].map((_, index) => (
        <div style={{ display: 'block' }} key={index}>
          Input {index + 1}: <input type='text' ref={el => inputRefs.current[index] = el} />
        </div>
      ))}
      <button type='button' onClick={handleClick}>I'm a button</button>
    </>
  );
}

export default Problem3;